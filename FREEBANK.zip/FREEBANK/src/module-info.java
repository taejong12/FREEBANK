module FREEBANK {
	requires javafx.controls;
	requires javafx.fxml;
	requires java.sql;
}