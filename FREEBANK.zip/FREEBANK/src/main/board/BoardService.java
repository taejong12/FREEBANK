package main.board;

public interface BoardService {
   
   void boardOutput();
   
}