package main.common;

public interface CommonService {

	void mainMenu();		//전체 메뉴
	void loginMainMenu();	//일반 로그인 메뉴
	void adminMainMenu();	//관리자 메뉴
	
}
