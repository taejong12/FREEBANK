package main.common;

public class CommonServiceImpl implements CommonService{

}
