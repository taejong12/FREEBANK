package main.common;

import javafx.scene.Parent;

public class CommonController {
	
	Parent root;

	
	public void setRoot(Parent root) {
		this.root = root;
		
	}

}
