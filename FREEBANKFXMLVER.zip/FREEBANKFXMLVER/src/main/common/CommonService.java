package main.common;

public interface CommonService {

}
